﻿#region Including
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
#endregion

namespace kalkulator_kozak
{
    class Program
    {
        public static bool debug = false;

        static void Main(string[] args)
        {
            string operation;
            operation = Console.ReadLine();
            Console.WriteLine(Evaluate(operation));

        }

        static double Evaluate(string expression)
        {
            double value = 0;
            if (debug)
            {
                Console.WriteLine("Evaluate(" + expression + ") {");
            }

            int op_index = Find_Operator(expression);
            if (debug)
            {
                Console.WriteLine("Find_Operator(" + expression + ") =" + op_index);
            }

            if (op_index > 0)
            {
                char op = expression[op_index];

                double l_val = Evaluate(expression.Substring(0, op_index));
                double r_val = Evaluate(expression.Substring(op_index + 1));

                if (op == 't')
                {
                    r_val = Evaluate(expression.Substring(op_index + 2, expression.Length - op_index - 3));
                }

                switch (op)
                {
                    case '*': value = l_val * r_val; break;
                    case '/': value = l_val / r_val; break;
                    case '+': value = l_val + r_val; break;
                    case '-': value = l_val - r_val; break;
                    case '^': value = Math.Pow(l_val, r_val); break;
                }
            }
            else
            {
                int val;
                bool res = int.TryParse(expression, out val);
                if (res)
                    value = val;
                else
                    if (expression.Substring(0, 4) == "sqrt")
                {
                    value = Math.Sqrt(Evaluate(expression.Substring(5, expression.Length - 6)));
                }
                else
                    value = Evaluate(expression.Substring(1, expression.Length - 2));
            }
            if (debug)
            {
                Console.WriteLine("Evaluate(" + expression + ") =" + value);
            }

            return value;
        }

        static int Find_Operator(string expression)
        {
            int bracket_counter = 0;
            int op_index = -1;
            int power = -1;
            int sq = -1;

            for (int i = 0; i < expression.Length; i++)
            {
                if (expression[i] == '(')
                {
                    bracket_counter += 1;
                }
                else
                if (expression[i] == ')')
                {
                    bracket_counter -= 1;
                }
                else
                    if ((expression[i] == '+' || expression[i] == '-') && bracket_counter == 0)
                {
                    if (expression[i] == '-' && i == 0)
                        continue;
                    return i;
                }
                else
                    if ((expression[i] == '*' || expression[i] == '/') && bracket_counter == 0 && (op_index == -1 || power == 1 || sq == 1))
                {
                    op_index = i;
                    power = 1;
                }
                else
                if (expression[i] == '^' && bracket_counter == 0 && (op_index == -1 || sq == 1) && power == -1)
                {
                    op_index = i;
                    power = 1;
                }
            }
            bracket_counter = 0;
            return op_index;
        }
    }
}