﻿namespace dice_lotto
{
    partial class Dice
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dice));
            this.btn_check = new System.Windows.Forms.Button();
            this.dice_2 = new System.Windows.Forms.Label();
            this.dice_3 = new System.Windows.Forms.Label();
            this.dice_5 = new System.Windows.Forms.Label();
            this.dice_4 = new System.Windows.Forms.Label();
            this.dice_1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.score_lbl = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.File_start = new System.Windows.Forms.ToolStripMenuItem();
            this.File_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.info = new System.Windows.Forms.ToolStripMenuItem();
            this.Info_gamerules = new System.Windows.Forms.ToolStripMenuItem();
            this.info_lbl = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_check
            // 
            this.btn_check.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_check.Location = new System.Drawing.Point(395, 629);
            this.btn_check.Name = "btn_check";
            this.btn_check.Size = new System.Drawing.Size(200, 60);
            this.btn_check.TabIndex = 6;
            this.btn_check.Text = "Roll";
            this.btn_check.UseVisualStyleBackColor = true;
            this.btn_check.Click += new System.EventHandler(this.btn_check_Click);
            // 
            // dice_2
            // 
            this.dice_2.Image = ((System.Drawing.Image)(resources.GetObject("dice_2.Image")));
            this.dice_2.Location = new System.Drawing.Point(260, 105);
            this.dice_2.Name = "dice_2";
            this.dice_2.Size = new System.Drawing.Size(100, 100);
            this.dice_2.TabIndex = 5;
            // 
            // dice_3
            // 
            this.dice_3.Image = ((System.Drawing.Image)(resources.GetObject("dice_3.Image")));
            this.dice_3.Location = new System.Drawing.Point(444, 105);
            this.dice_3.Name = "dice_3";
            this.dice_3.Size = new System.Drawing.Size(100, 100);
            this.dice_3.TabIndex = 4;
            // 
            // dice_5
            // 
            this.dice_5.Image = ((System.Drawing.Image)(resources.GetObject("dice_5.Image")));
            this.dice_5.Location = new System.Drawing.Point(798, 105);
            this.dice_5.Name = "dice_5";
            this.dice_5.Size = new System.Drawing.Size(100, 100);
            this.dice_5.TabIndex = 3;
            // 
            // dice_4
            // 
            this.dice_4.Image = ((System.Drawing.Image)(resources.GetObject("dice_4.Image")));
            this.dice_4.Location = new System.Drawing.Point(619, 105);
            this.dice_4.Name = "dice_4";
            this.dice_4.Size = new System.Drawing.Size(100, 100);
            this.dice_4.TabIndex = 1;
            // 
            // dice_1
            // 
            this.dice_1.Image = ((System.Drawing.Image)(resources.GetObject("dice_1.Image")));
            this.dice_1.Location = new System.Drawing.Point(76, 105);
            this.dice_1.Name = "dice_1";
            this.dice_1.Size = new System.Drawing.Size(100, 100);
            this.dice_1.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox1.Location = new System.Drawing.Point(97, 257);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(50, 50);
            this.textBox1.TabIndex = 7;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox2.Location = new System.Drawing.Point(287, 257);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(50, 50);
            this.textBox2.TabIndex = 8;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox3.Location = new System.Drawing.Point(472, 257);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(50, 50);
            this.textBox3.TabIndex = 9;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox4.Location = new System.Drawing.Point(649, 257);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(50, 50);
            this.textBox4.TabIndex = 10;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox5.Location = new System.Drawing.Point(825, 257);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(50, 50);
            this.textBox5.TabIndex = 11;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // score_lbl
            // 
            this.score_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.score_lbl.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.score_lbl.Location = new System.Drawing.Point(229, 505);
            this.score_lbl.Name = "score_lbl";
            this.score_lbl.Size = new System.Drawing.Size(550, 60);
            this.score_lbl.TabIndex = 12;
            this.score_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.info});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(984, 24);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.File_start,
            this.File_exit});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // File_start
            // 
            this.File_start.Name = "File_start";
            this.File_start.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F1)));
            this.File_start.Size = new System.Drawing.Size(144, 22);
            this.File_start.Text = "Start";
            this.File_start.Click += new System.EventHandler(this.File_start_Click);
            // 
            // File_exit
            // 
            this.File_exit.Name = "File_exit";
            this.File_exit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Delete)));
            this.File_exit.Size = new System.Drawing.Size(144, 22);
            this.File_exit.Text = "Exit";
            this.File_exit.Click += new System.EventHandler(this.File_exit_Click);
            // 
            // info
            // 
            this.info.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Info_gamerules});
            this.info.Name = "info";
            this.info.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.info.Size = new System.Drawing.Size(40, 20);
            this.info.Text = "Info";
            // 
            // Info_gamerules
            // 
            this.Info_gamerules.Name = "Info_gamerules";
            this.Info_gamerules.Size = new System.Drawing.Size(180, 22);
            this.Info_gamerules.Text = "Game Rules";
            this.Info_gamerules.Click += new System.EventHandler(this.Info_gamerules_Click);
            // 
            // info_lbl
            // 
            this.info_lbl.AutoSize = true;
            this.info_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.info_lbl.Location = new System.Drawing.Point(74, 358);
            this.info_lbl.Name = "info_lbl";
            this.info_lbl.Size = new System.Drawing.Size(0, 25);
            this.info_lbl.TabIndex = 14;
            // 
            // Dice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 761);
            this.Controls.Add(this.info_lbl);
            this.Controls.Add(this.score_lbl);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btn_check);
            this.Controls.Add(this.dice_2);
            this.Controls.Add(this.dice_3);
            this.Controls.Add(this.dice_5);
            this.Controls.Add(this.dice_4);
            this.Controls.Add(this.dice_1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1000, 800);
            this.MinimumSize = new System.Drawing.Size(1000, 700);
            this.Name = "Dice";
            this.Text = "Dice Lotto";
            this.Load += new System.EventHandler(this.Dice_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label dice_1;
        private System.Windows.Forms.Label dice_4;
        private System.Windows.Forms.Label dice_5;
        private System.Windows.Forms.Label dice_3;
        private System.Windows.Forms.Label dice_2;
        private System.Windows.Forms.Button btn_check;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label score_lbl;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem File_start;
        private System.Windows.Forms.ToolStripMenuItem File_exit;
        private System.Windows.Forms.ToolStripMenuItem info;
        private System.Windows.Forms.ToolStripMenuItem Info_gamerules;
        private System.Windows.Forms.Label info_lbl;
    }
}

