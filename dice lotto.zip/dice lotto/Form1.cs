﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dice_lotto
{
    #region Declaration

    public partial class Dice : Form
    {


        Image[] diceImages;
        int[] dices;
        int[] box_values;
        Random rand;
        int points = 0;


        #endregion

        #region Initialization

        public Dice()
        { 
            InitializeComponent();
        }

        private void Dice_Load(object sender, EventArgs e)
        {
            diceImages = new Image[7];
            diceImages[0] = Properties.Resources.dice_blank;
            diceImages[1] = Properties.Resources.dice_1;
            diceImages[2] = Properties.Resources.dice_2;
            diceImages[3] = Properties.Resources.dice_3;
            diceImages[4] = Properties.Resources.dice_4;
            diceImages[5] = Properties.Resources.dice_5;
            diceImages[6] = Properties.Resources.dice_6;

            dices = new int[5] { 0, 0, 0, 0, 0 };
            box_values = new int[5] { 0, 0, 0, 0, 0 };

            rand = new Random();
        }

        #endregion

        #region Private Methods

        private void btn_check_Click(object sender, EventArgs e)
        {
            info_lbl.Text = "";
            Roll();
        }

        private void Roll()
        {
            for (int i = 0; i < dices.Length; i++)
            {
                dices[i] = rand.Next(1, 7);
            }

            dice_1.Image = diceImages[dices[0]];
            dice_2.Image = diceImages[dices[1]];
            dice_3.Image = diceImages[dices[2]];
            dice_4.Image = diceImages[dices[3]];
            dice_5.Image = diceImages[dices[4]];

            if (textBox1.Text != "")
                box_values[0] = Convert.ToInt32(textBox1.Text);
            else
                box_values[0] = 0;

            if (textBox2.Text != "")
                box_values[1] = Convert.ToInt32(textBox2.Text);
            else
                box_values[1] = 0;

            if (textBox3.Text != "")
                box_values[2] = Convert.ToInt32(textBox3.Text);
            else
                box_values[2] = 0;

            if (textBox4.Text != "")
                box_values[3] = Convert.ToInt32(textBox4.Text);
            else
                box_values[3] = 0;

            if (textBox5.Text != "")
                box_values[4] = Convert.ToInt32(textBox5.Text);
            else
                box_values[4] = 0;


            for (int i = 0; i < dices.Length; i++)
            {
                if (box_values[i] == dices[i])
                {
                    points += 2;
                    dices[i] = 0;
                    box_values[i] = 0;
                }
            }

            for (int i = 0; i < dices.Length; i++)
            {
                for (int j = 0; j < dices.Length; j++)
                {
                    if (box_values[i] == dices[j] && box_values[i] != 0 && dices[j] != 0)
                    {
                        points += 1;
                        box_values[i] = 0;
                        dices[j] = 0;
                        break;
                    }
                }
            }

            score_lbl.Text = "You've got " + Convert.ToString(points) + "/10 points";
        }
        #endregion

        private void File_start_Click(object sender, EventArgs e)
        {
            Roll();
        }

        private void File_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Info_gamerules_Click(object sender, EventArgs e)
        {
            info_lbl.Text = "In this game you have to guess which numbers will be drawn by dice\n2 pkt if you guess number on the correct dice\n1 pkt if you guess correct number but on the different dice";
        }
    }
    }
